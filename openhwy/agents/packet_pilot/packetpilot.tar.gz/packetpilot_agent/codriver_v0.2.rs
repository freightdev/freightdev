// CoDriver v0.2 - Autonomous coordinator with PacketPilot integration
// Uses hostbox qwen2.5:14b as brain
// Now includes PacketPilot agent for paperwork automation

use reqwest::Client;
use serde_json::json;
use std::fs;
use std::path::Path;
use std::time::Duration;
use tokio::time::sleep;

const HELPBOX_OLLAMA: &str = "http://192.168.12.136:11434";
const BRAIN_MODEL: &str = "qwen2.5-coder:14b-instruct-q4_K_M";
const CHAT_FILE: &str = "/home/admin/freightdev/openhwy/.codriver/chats/codriver.txt";
const CHECK_INTERVAL_MS: u64 = 500;

// PacketPilot endpoint
const PACKETPILOT_URL: &str = "http://localhost:8080/api/packetpilot";

struct CoDriver {
    client: Client,
    last_line_count: usize,
}

impl CoDriver {
    fn new() -> Self {
        Self {
            client: Client::new(),
            last_line_count: 0,
        }
    }

    async fn initialize(&mut self) -> Result<(), Box<dyn std::error::Error>> {
        println!("CoDriver v0.2 Online");
        println!("Brain: helpbox qwen2.5-coder:14b-instruct-q4_K_M");
        println!("Agents: PacketPilot v0.0.1");
        println!("Monitoring: {}", CHAT_FILE);
        println!();

        if !Path::new(CHAT_FILE).exists() {
            fs::write(CHAT_FILE, "# CoDriver Chat\n# Write messages as: user: \"your message\"\n\n")?;
        }

        let content = fs::read_to_string(CHAT_FILE)?;
        self.last_line_count = content.lines().count();

        println!("Verifying Ollama connection...");
        match self.verify_ollama().await {
            Ok(_) => println!("✓ Connected to hostbox Ollama"),
            Err(e) => {
                eprintln!("Cannot connect to hostbox Ollama: {}", e);
                return Err(e);
            }
        }

        // Check PacketPilot
        match self.verify_packetpilot().await {
            Ok(_) => println!("✓ Connected to PacketPilot"),
            Err(_) => println!("⚠️  PacketPilot not available (optional)"),
        }

        println!("\n✅ CoDriver ready!\n");
        Ok(())
    }

    async fn verify_ollama(&self) -> Result<(), Box<dyn std::error::Error>> {
        let response = self.client
            .get(format!("{}/api/tags", HELPBOX_OLLAMA))
            .timeout(Duration::from_secs(5))
            .send()
            .await?;

        if !response.status().is_success() {
            return Err(format!("Ollama returned: {}", response.status()).into());
        }

        Ok(())
    }

    async fn verify_packetpilot(&self) -> Result<(), Box<dyn std::error::Error>> {
        let response = self.client
            .get(format!("{}/health", PACKETPILOT_URL))
            .timeout(Duration::from_secs(2))
            .send()
            .await?;

        if !response.status().is_success() {
            return Err("PacketPilot not available".into());
        }

        Ok(())
    }

    async fn check_new_messages(&mut self) -> Result<Option<String>, Box<dyn std::error::Error>> {
        let content = fs::read_to_string(CHAT_FILE)?;
        let lines: Vec<&str> = content.lines().collect();

        if lines.len() > self.last_line_count {
            let new_lines: Vec<&str> = lines[self.last_line_count..].to_vec();
            self.last_line_count = lines.len();

            for line in new_lines.iter().rev() {
                if line.trim().starts_with("user:") {
                    let message = line.trim()
                        .strip_prefix("user:")
                        .unwrap_or("")
                        .trim()
                        .trim_matches('"')
                        .to_string();

                    if !message.is_empty() {
                        return Ok(Some(message));
                    }
                }
            }
        }

        Ok(None)
    }

    async fn query_brain(&self, prompt: &str) -> Result<String, Box<dyn std::error::Error>> {
        let payload = json!({
            "model": BRAIN_MODEL,
            "prompt": prompt,
            "stream": false,
            "options": {
                "temperature": 0.7,
                "num_predict": 500
            }
        });

        let response = self.client
            .post(format!("{}/api/generate", HELPBOX_OLLAMA))
            .json(&payload)
            .timeout(Duration::from_secs(120))
            .send()
            .await?;

        if !response.status().is_success() {
            return Err(format!("Ollama query failed: {}", response.status()).into());
        }

        let result: serde_json::Value = response.json().await?;
        let answer = result["response"]
            .as_str()
            .unwrap_or("(no response)")
            .trim()
            .to_string();

        Ok(answer)
    }

    fn respond(&self, message: &str) -> Result<(), Box<dyn std::error::Error>> {
        let mut content = fs::read_to_string(CHAT_FILE)?;
        content.push_str(&format!("codriver: \"{}\"\n", message));
        fs::write(CHAT_FILE, content)?;
        Ok(())
    }

    async fn call_packetpilot(&self, intent: &str, payload: serde_json::Value) -> Result<serde_json::Value, Box<dyn std::error::Error>> {
        println!("📞 Calling PacketPilot: {}", intent);

        let request = json!({
            "intent": intent,
            "payload": payload,
        });

        let response = self.client
            .post(PACKETPILOT_URL)
            .json(&request)
            .timeout(Duration::from_secs(60))
            .send()
            .await?;

        if !response.status().is_success() {
            return Err(format!("PacketPilot error: {}", response.status()).into());
        }

        let result: serde_json::Value = response.json().await?;
        Ok(result)
    }

    async fn handle_task(&self, task: String) -> Result<(), Box<dyn std::error::Error>> {
        println!("📥 User task: {}", task);
        self.respond("Received. Thinking...")?;

        let decision_prompt = format!(
            r#"You are CoDriver, an autonomous AI coordinator.

User task: "{}"

Available capabilities:
1. fill_packet - Fill out broker carrier packets (PacketPilot)
2. sign_ratecon - Sign rate confirmations (PacketPilot)
3. monitor_email - Check email for packets (PacketPilot)
4. generate_component - Generate React/TypeScript code
5. search_web - Search the web
6. respond_only - Just respond to the message

Keywords:
- "packet", "carrier packet", "broker" → fill_packet
- "sign", "rate con" → sign_ratecon  
- "check email", "inbox" → monitor_email
- "code", "component" → generate_component
- "search", "find" → search_web

Respond with ONLY the capability name."#,
            task
        );

        let decision = self.query_brain(&decision_prompt).await?;
        let action = decision.lines().next().unwrap_or("respond_only").trim().to_lowercase();

        println!("🧠 Decision: {}", action);

        match action.as_str() {
            s if s.contains("fill_packet") => {
                self.respond("Starting PacketPilot to fill the packet...")?;
                
                // Extract broker name from task
                let broker = if task.to_lowercase().contains("ch robinson") {
                    "CH Robinson"
                } else if task.to_lowercase().contains("tql") {
                    "TQL"
                } else {
                    "Unknown Broker"
                };

                let payload = json!({
                    "request_type": {
                        "type": "fill_packet",
                        "broker_name": broker,
                        "packet_url": null,
                        "packet_pdf": null,
                    },
                    "data": {}
                });

                match self.call_packetpilot("fill_packet", payload).await {
                    Ok(result) => {
                        self.respond(&format!("✓ Filled out the {} packet! Check your downloads.", broker))?;
                        println!("✓ PacketPilot completed: {:?}", result);
                    }
                    Err(e) => {
                        self.respond(&format!("Error filling packet: {}", e))?;
                        println!("❌ PacketPilot failed: {}", e);
                    }
                }
            }

            s if s.contains("sign_ratecon") => {
                self.respond("Starting PacketPilot to sign the rate confirmation...")?;
                
                let payload = json!({
                    "request_type": {
                        "type": "sign_ratecon",
                        "ratecon_pdf": "placeholder_base64",
                        "signature_image": null,
                    },
                    "data": {}
                });

                match self.call_packetpilot("sign_ratecon", payload).await {
                    Ok(_) => {
                        self.respond("✓ Signed the rate confirmation!")?;
                        println!("✓ Rate confirmation signed");
                    }
                    Err(e) => {
                        self.respond(&format!("Error signing: {}", e))?;
                    }
                }
            }

            s if s.contains("monitor_email") => {
                self.respond("Checking your email for new packets...")?;
                
                let payload = json!({
                    "request_type": {
                        "type": "monitor_email",
                        "email_address": "dispatch@fed.com",
                        "keywords": ["carrier packet", "rate confirmation"],
                    },
                    "data": {}
                });

                match self.call_packetpilot("monitor_email", payload).await {
                    Ok(result) => {
                        let count = result["data"]["found_messages"].as_u64().unwrap_or(0);
                        self.respond(&format!("Found {} new messages with packets", count))?;
                    }
                    Err(e) => {
                        self.respond(&format!("Error checking email: {}", e))?;
                    }
                }
            }

            s if s.contains("respond_only") || s.contains("conversation") => {
                let response_prompt = format!(
                    r#"You are CoDriver, a friendly AI assistant.

User message: "{}"

Respond helpfully (1-3 sentences)."#,
                    task
                );

                let response = self.query_brain(&response_prompt).await?;
                self.respond(&response)?;
                println!("✓ Responded to user\n");
            }

            _ => {
                self.respond("Not sure how to handle that yet. Try: 'fill packet', 'sign ratecon', or 'check email'")?;
                println!("⚠️  Unknown action: {}\n", action);
            }
        }

        Ok(())
    }

    async fn run(&mut self) -> Result<(), Box<dyn std::error::Error>> {
        loop {
            if let Some(task) = self.check_new_messages().await? {
                if let Err(e) = self.handle_task(task).await {
                    eprintln!("❌ Task failed: {}", e);
                    self.respond(&format!("Error: {}", e))?;
                }
            }

            sleep(Duration::from_millis(CHECK_INTERVAL_MS)).await;
        }
    }
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let mut codriver = CoDriver::new();
    codriver.initialize().await?;
    codriver.run().await?;

    Ok(())
}
