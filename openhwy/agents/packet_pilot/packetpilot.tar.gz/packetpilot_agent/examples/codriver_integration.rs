// CoDriver Integration for PacketPilot
// This shows how CoDriver v0.1 can call PacketPilot

use reqwest::Client;
use serde_json::json;
use std::time::Duration;

const PACKETPILOT_URL: &str = "http://localhost:8080/api/packetpilot";

// ============================================================================
// CODRIVER → PACKETPILOT COMMUNICATION
// ============================================================================

pub async fn call_packetpilot_from_codriver(
    intent: &str,
    payload: serde_json::Value,
) -> Result<serde_json::Value, Box<dyn std::error::Error>> {
    let client = Client::new();
    
    println!("📞 CoDriver calling PacketPilot");
    println!("   Intent: {}", intent);
    println!("   Payload: {}", serde_json::to_string_pretty(&payload)?);
    
    let request = json!({
        "intent": intent,
        "payload": payload,
    });
    
    let response = client
        .post(PACKETPILOT_URL)
        .json(&request)
        .timeout(Duration::from_secs(60))
        .send()
        .await?;
    
    if !response.status().is_success() {
        return Err(format!("PacketPilot returned error: {}", response.status()).into());
    }
    
    let result: serde_json::Value = response.json().await?;
    
    println!("✓ PacketPilot response received");
    Ok(result)
}

// ============================================================================
// EXAMPLE USAGE IN CODRIVER
// ============================================================================

/// Example: CoDriver handles a user request to fill a broker packet
pub async fn example_fill_packet() -> Result<(), Box<dyn std::error::Error>> {
    println!("\n=== EXAMPLE: Fill Broker Packet ===\n");
    
    // User tells CoDriver: "Fill out the CH Robinson packet"
    
    let payload = json!({
        "request_type": {
            "type": "fill_packet",
            "broker_name": "CH Robinson",
            "packet_url": "https://www.chrobinson.com/carrier-packet.pdf",
        },
        "data": {}
    });
    
    let result = call_packetpilot_from_codriver("fill_packet", payload).await?;
    
    println!("PacketPilot completed the packet!");
    println!("Result: {}", serde_json::to_string_pretty(&result)?);
    
    // CoDriver would then:
    // 1. Save the filled PDF
    // 2. Respond to user: "I've filled out the CH Robinson packet for you!"
    // 3. Optionally ask: "Would you like me to email it to them?"
    
    Ok(())
}

/// Example: CoDriver handles signing a rate confirmation
pub async fn example_sign_ratecon() -> Result<(), Box<dyn std::error::Error>> {
    println!("\n=== EXAMPLE: Sign Rate Confirmation ===\n");
    
    // User tells CoDriver: "Sign this rate confirmation"
    // (User has attached a PDF to the email)
    
    let payload = json!({
        "request_type": {
            "type": "sign_ratecon",
            "ratecon_pdf": "base64_encoded_pdf_here...",
            "signature_image": "base64_encoded_signature_here...",
        },
        "data": {}
    });
    
    let result = call_packetpilot_from_codriver("sign_ratecon", payload).await?;
    
    println!("PacketPilot signed the rate confirmation!");
    println!("Result: {}", serde_json::to_string_pretty(&result)?);
    
    // CoDriver would then respond:
    // "I've signed the rate confirmation. Ready to send it back!"
    
    Ok(())
}

/// Example: CoDriver monitors email for new packets
pub async fn example_monitor_email() -> Result<(), Box<dyn std::error::Error>> {
    println!("\n=== EXAMPLE: Monitor Email ===\n");
    
    // CoDriver runs this periodically or when user asks
    
    let payload = json!({
        "request_type": {
            "type": "monitor_email",
            "email_address": "dispatch@fed.com",
            "keywords": ["carrier packet", "rate confirmation", "w9"],
        },
        "data": {}
    });
    
    let result = call_packetpilot_from_codriver("monitor_email", payload).await?;
    
    println!("PacketPilot found new messages!");
    println!("Result: {}", serde_json::to_string_pretty(&result)?);
    
    // CoDriver would then:
    // 1. Notify user: "You have 3 new carrier packets in your inbox"
    // 2. Ask: "Would you like me to fill them out?"
    
    Ok(())
}

// ============================================================================
// UPDATED CODRIVER v0.2 WITH PACKETPILOT INTEGRATION
// ============================================================================

pub async fn enhanced_codriver_decision(task: &str) -> String {
    // Enhanced decision making that includes PacketPilot
    
    let decision_prompt = format!(
        r#"You are CoDriver, an autonomous AI coordinator managing a 4-node Ollama cluster.

User task: "{}"

Available capabilities:
1. generate_component - Generate React/TypeScript components using helpbox (L3)
2. find_leads - Search for paid development work ($1k+ gigs)
3. analyze_image - Process images using workbox (L1)
4. search_web - Search the web for information
5. fill_packet - Use PacketPilot to fill out broker carrier packets (NEW!)
6. sign_ratecon - Use PacketPilot to sign rate confirmations (NEW!)
7. monitor_email - Use PacketPilot to check email for packets (NEW!)
8. respond_only - Just respond to the user's message

Detect keywords:
- "packet", "carrier packet", "broker packet" → fill_packet
- "sign", "rate con", "rate confirmation" → sign_ratecon
- "check email", "inbox", "new packets" → monitor_email

What should you do? Respond with ONLY the capability name."#,
        task
    );
    
    // This would be sent to brain (qwen2.5:14b)
    decision_prompt
}

// ============================================================================
// MAIN (for testing)
// ============================================================================

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    println!("🚀 CoDriver → PacketPilot Integration Test\n");
    
    // Test all examples
    example_fill_packet().await?;
    example_sign_ratecon().await?;
    example_monitor_email().await?;
    
    println!("\n✅ All examples completed!\n");
    
    Ok(())
}
